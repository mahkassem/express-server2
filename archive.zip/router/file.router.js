"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const file_controller_1 = require("../controllers/file.controller");
const auth_middleware_1 = require("../utils/middlewares/auth.middleware");
const file_validator_1 = require("../validators/file.validator");
const fileRouter = (0, express_1.Router)();
/**
 * @description Get file by name
 * @route GET /file/:file_name
 * @access Public
 */
fileRouter.get("/:file_name", // ? uri
auth_middleware_1.authGuard, // ! middleware
file_validator_1.validateGetFileByName, // ! middleware
file_controller_1.getFileByName // * controller
);
fileRouter.post("/upload", // ? uri
auth_middleware_1.authGuard, // ! middleware
file_controller_1.uploadFile // * controller
);
exports.default = fileRouter;
