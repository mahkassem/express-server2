"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const users_entity_1 = __importDefault(require("../../entities/users.entity"));
const supertest_1 = __importDefault(require("supertest"));
const app_1 = __importDefault(require("../../app"));
const _usersEntity = new users_entity_1.default();
let user;
describe("Users API testing", () => {
    beforeAll(() => __awaiter(void 0, void 0, void 0, function* () {
        user = {
            name: "John Doe",
            username: "johndoe",
            password: "123456"
        };
    }));
    it("should return user and status 201", () => __awaiter(void 0, void 0, void 0, function* () {
        const registerReq = yield (0, supertest_1.default)(app_1.default)
            .post("/api/auth/register")
            .send(user);
        const createdUser = registerReq.body;
        expect(createdUser.name).toEqual(user.name);
        expect(createdUser.username).toEqual(user.username);
        expect(registerReq.status).toEqual(201);
        user.id = createdUser.id;
    }));
    it("should faild and resturn status 400", () => __awaiter(void 0, void 0, void 0, function* () {
        const registerReq = yield (0, supertest_1.default)(app_1.default)
            .post("/api/auth/register")
            .send({ user });
        expect(registerReq.status).toEqual(400);
    }));
    afterAll(() => __awaiter(void 0, void 0, void 0, function* () {
        yield _usersEntity.delete(user.id);
    }));
});
