"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_router_1 = __importDefault(require("./auth.router"));
const file_router_1 = __importDefault(require("./file.router"));
const student_router_1 = __importDefault(require("./student.router"));
const user_router_1 = __importDefault(require("./user.router"));
const nodemailer_1 = __importDefault(require("nodemailer"));
const router = (0, express_1.Router)();
router.use("/auth", auth_router_1.default);
router.use("/files", file_router_1.default);
router.use("/user", user_router_1.default);
router.use("/student", student_router_1.default);
router.get("/send-mail", (req, res) => {
    try {
        const transport = nodemailer_1.default.createTransport({
            host: "smtp.mailtrap.io",
            port: 587,
            auth: {
                user: "08ecd36cc247cb",
                pass: "40543242697c2b"
            }
        });
        const message = {
            from: "School Admin <admin@school.test>",
            to: "Your Name <you@school.test>",
            subject: "Test email",
            text: "Hello world",
            html: "<b>Hello world</b>"
        };
        transport.sendMail(message);
        res.send("Mail sent successfully");
    }
    catch (error) {
        res.status(500).send(error);
    }
});
exports.default = router;
