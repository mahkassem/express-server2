"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const users_entity_1 = __importDefault(require("../entities/users.entity"));
const env_helper_1 = __importDefault(require("../utils/helpers/env.helper"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const _usersEntity = new users_entity_1.default();
class AuthService {
    getById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const user = yield _usersEntity.getById(id);
            // delete password from response
            delete user.password;
            return user;
        });
    }
    register(user, isTest = false) {
        return __awaiter(this, void 0, void 0, function* () {
            const hashedPassword = bcrypt_1.default.hashSync(user.password + (0, env_helper_1.default)("BCRYPT_SECRET"), parseInt((0, env_helper_1.default)("BCRYPT_SALT")));
            const createdUser = yield _usersEntity.create(Object.assign(Object.assign({}, user), { password: hashedPassword }));
            // delete password from response
            if (!isTest)
                delete createdUser.password;
            return createdUser;
        });
    }
    login(user) {
        return __awaiter(this, void 0, void 0, function* () {
            const { username, password } = user;
            // check if user exists
            const userExists = yield _usersEntity.getByUsername(username);
            if (!userExists)
                throw new Error("User does not exist. Please register first.");
            // compare passwords
            const passwordIsValid = bcrypt_1.default.compareSync(password + (0, env_helper_1.default)("BCRYPT_SECRET"), userExists.password);
            if (!passwordIsValid)
                throw new Error("Invalid password. Please try again.");
            // generate token
            const token = this.generateToken(userExists);
            // remove password from response
            delete userExists.password;
            return Object.assign(Object.assign({}, userExists), { token });
        });
    }
    generateToken(user) {
        return jsonwebtoken_1.default.sign({ sub: user.username }, (0, env_helper_1.default)("JWT_SECRET"), {
            expiresIn: "1d",
        });
    }
}
exports.default = AuthService;
