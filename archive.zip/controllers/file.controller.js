"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.uploadFile = exports.getFileByName = void 0;
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const path_2 = require("path");
const getFileByName = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const fileName = req.params.file_name;
    const basePath = path_1.default.join(__dirname, "..", "..", "storage");
    try {
        const file = fs_1.default.readFileSync(`${basePath}/${fileName}`, "utf-8");
        res.send(file);
    }
    catch (error) {
        res.status(500).send("Internal server error");
        // log error for dev use
    }
    return;
});
exports.getFileByName = getFileByName;
const uploadFile = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { file } = req.files;
        if (file.size > 1 * 1024 * 1024)
            throw new Error("File size is too large");
        const path = (0, path_2.join)(__dirname, "..", "..", "storage", file.name);
        yield file.mv(path);
        res.send("File uploaded successfully");
    }
    catch (error) {
        res.status(500).send(error.message);
        // log error for dev use
    }
});
exports.uploadFile = uploadFile;
