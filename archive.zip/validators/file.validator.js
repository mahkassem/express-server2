"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateGetFileByName = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const validateGetFileByName = (req, res, next) => {
    const fileName = req.params.file_name;
    const basePath = path_1.default.join(__dirname, "..", "..", "storage");
    try {
        fs_1.default.readFileSync(`${basePath}/${fileName}`, "utf-8");
    }
    catch (error) {
        // make sure error is file not found
        const errorCode = error.code;
        if (errorCode === "ENOENT") {
            return res.status(404).send("File not found");
        }
    }
    next();
};
exports.validateGetFileByName = validateGetFileByName;
