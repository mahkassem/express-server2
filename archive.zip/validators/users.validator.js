"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.loginUserValidator = exports.createUserValidator = void 0;
const users_entity_1 = __importDefault(require("../entities/users.entity"));
const _usersEntity = new users_entity_1.default();
const createUserValidator = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    const { name, username, password } = req.body;
    // create error bag
    const errors = [];
    // check if name is empty
    if (!name) {
        errors.push({ "name": "name is required" });
    }
    // check if username is empty
    if (!username) {
        errors.push({ "username": "username is required" });
    }
    else {
        // check if username is already taken
        const user = yield _usersEntity.getByUsername(username);
        if (user) {
            errors.push({ "username": "username is already taken" });
        }
    }
    // check if password is empty
    if (!password) {
        errors.push({ "password": "password is required" });
    }
    // if there are errors, return them
    if (errors.length > 0) {
        return res.status(400).send(errors);
    }
    // if there are no errors, call next middleware
    next();
});
exports.createUserValidator = createUserValidator;
const loginUserValidator = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    const { username, password } = req.body;
    // create error bag
    const errors = [];
    // check if username is empty
    if (!username) {
        errors.push({ "username": "username is required" });
    }
    // check if password is empty
    if (!password) {
        errors.push({ "password": "password is required" });
    }
    // if there are errors, return them
    if (errors.length > 0) {
        return res.status(400).send(errors);
    }
    // if there are no errors, call next middleware
    next();
});
exports.loginUserValidator = loginUserValidator;
